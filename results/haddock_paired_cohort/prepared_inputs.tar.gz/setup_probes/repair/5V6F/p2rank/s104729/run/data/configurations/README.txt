################################################################################
# Information about configuration files present in the same directory #
################################################################################
"run/data/configurations/raw_input.toml": An untouched copy of the raw input file, as provided by the user.
"run/data/configurations/cleaned_input.toml": Pre-parsed input file where (eventually) some indexing and modifications were applied to ensure further processing.
"run/data/configurations/enhanced_haddock_params.toml": Final input file with detailed default parameters.
