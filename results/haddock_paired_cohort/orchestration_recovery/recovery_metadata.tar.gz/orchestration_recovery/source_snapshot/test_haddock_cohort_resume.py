"""Preserving HADDOCK receipt recovery; no native cohort launch in tests."""
from copy import deepcopy
import gzip
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from aav_benchmark import haddock_cohort_resume as resume


class RecoveryControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = resume.frozen.ROOT
        cls.base = cls.root / 'results/haddock_paired_cohort'
        cls.plan_path = cls.base / 'prepared_plan.json'
        cls.freeze = cls.base / 'execution_freeze.json'
        cls.plan = json.loads(cls.plan_path.read_text())
        cls.job = next(j for j in cls.plan['jobs'] if j['job_id'] == resume.ORPHAN_JOB)
        cls.directory = cls.root / cls.job['directory']

    def test_documented_relative_CLI_paths_become_absolute_before_frozen_call(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            destination = Path(directory) / 'job'; destination.mkdir()
            relative = str(destination.relative_to(self.root))
            plan = Path(directory) / 'plan.json'
            plan.write_text(json.dumps(dict(driver=self.plan['driver'], jobs=[dict(job_id='test', directory=relative, config={})])))
            freeze = Path(directory) / 'freeze.json'; freeze.write_text('{}')
            def fake_native(plan_path, freeze_path, job_id, root):
                self.assertTrue(root.is_absolute())
                self.assertTrue(plan_path.is_absolute())
                self.assertTrue(freeze_path.is_absolute())
                result = dict(job_id=job_id, terminal=True, status='completed')
                (destination / 'execution.json').write_text(json.dumps(result))
                return result
            with patch.object(resume.frozen, 'execute_job', fake_native):
                result = resume.measured_native_worker(self.root, plan.relative_to(self.root), freeze.relative_to(self.root), 'test')
            self.assertEqual(result['result']['status'], 'completed')
            resources = json.loads((destination / 'measured_resources.json').read_text())
            self.assertGreaterEqual(resources['measured_usage']['wall_seconds'], 0)
            self.assertGreaterEqual(resources['measured_usage']['CPU_seconds'], 0)
            self.assertEqual(resources['native_cpus_per_job'], 1)

    def test_relative_pin_failure_is_reproduced_and_absolute_normalization_fixes_it(self):
        relative_plan = self.plan_path.relative_to(self.root)
        with self.assertRaises(ValueError):
            resume.pin(relative_plan, self.root)
        root, plan, freeze = resume.normalize_paths(self.root, relative_plan, self.freeze.relative_to(self.root))
        self.assertEqual(resume.pin(plan, root)['sha256'], resume.PLAN_SHA)
        self.assertEqual(resume.pin(freeze, root)['sha256'], resume.ORIGINAL_FREEZE_SHA)

    def test_existing_first_run_is_never_reexecuted_by_frozen_helper(self):
        with patch.object(resume.frozen.subprocess, 'run') as native:
            with self.assertRaisesRegex(resume.frozen.PairedCohortError, 'Refuse repeated'):
                resume.frozen.execute_job(self.plan_path.resolve(), self.freeze.resolve(), resume.ORPHAN_JOB, self.root.resolve())
            native.assert_not_called()

    def test_actual_first_outputs_are_complete_without_inventing_process_telemetry(self):
        log = resume.completion_log_proof(self.directory / 'stdout.log', self.freeze)
        proof = resume.completed_output_proof(self.directory, resume.ORPHAN_JOB, self.job)
        self.assertEqual(proof['actual_initial_models'], 20)
        self.assertEqual(proof['actual_refined_models'], 20)
        self.assertEqual(proof['full_model_atom_count'], 1083)
        self.assertEqual(len(proof['refinement_lineage']), 20)
        self.assertEqual(log['elapsed_seconds'], 373)
        self.assertIsNone(log['process_return_code'])
        self.assertIsNone(log['process_CPU_seconds'])
        self.assertIsNone(log['measured_external_elapsed_seconds'])

    def test_sanitized_PDB_serialization_preserves_all_physical_input_atoms(self):
        for molecule, count in [('receptor', 760), ('glycan', 23)]:
            proof = resume.coordinate_identity(self.directory.parent / 'data' / (molecule + '.pdb'),
                                               self.directory / 'run/data/0_topoaa' / (molecule + '.pdb'))
            self.assertEqual(proof['atom_count'], count)
            self.assertEqual(proof['maximum_coordinate_change_A'], 0)
            self.assertFalse(proof['byte_identical'])

    def _copy_outputs(self, directory):
        destination = Path(directory) / 'copy'; destination.mkdir()
        for stage in ['0_topoaa', '1_rigidbody', '2_flexref']:
            shutil.copytree(self.directory / 'run' / stage, destination / 'run' / stage)
        return destination

    def test_missing_model_and_incomplete_score_or_lineage_reject_adoption(self):
        for corruption in ['missing_model', 'score', 'lineage']:
            with tempfile.TemporaryDirectory(dir=self.base) as directory:
                destination = self._copy_outputs(directory)
                if corruption == 'missing_model':
                    next((destination / 'run/2_flexref').glob('*.pdb')).unlink()
                else:
                    path = destination / 'run/2_flexref/io.json'
                    data = json.loads(path.read_text())
                    if corruption == 'score':
                        data['output'][0]['unw_energies']['vdw'] = float('nan')
                    else:
                        data['output'][0]['ori_name'] = 'unplanned.pdb'
                    path.write_text(json.dumps(data))
                with self.assertRaises(resume.RecoveryError):
                    resume.completed_output_proof(destination, resume.ORPHAN_JOB, self.job)

    def test_missing_finished_marker_does_not_establish_completion(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            path = Path(directory) / 'stdout'
            path.write_text((self.directory / 'stdout.log').read_text().replace('cli INFO] Finished at ', 'cli INFO] Interrupted at '))
            with self.assertRaisesRegex(resume.RecoveryError, 'completion'):
                resume.completion_log_proof(path, self.freeze)

    def test_resource_delta_excludes_other_processes_and_does_not_subtract_RSS(self):
        before = dict(worker=dict(user_seconds=2, system_seconds=1, maximum_rss=100),
                      waited_children=dict(user_seconds=10, system_seconds=5, maximum_rss=900))
        after = dict(worker=dict(user_seconds=2.5, system_seconds=1.5, maximum_rss=110),
                     waited_children=dict(user_seconds=13, system_seconds=7, maximum_rss=1000))
        measured = resume.measured_usage(before, after, 9)
        self.assertEqual(measured['CPU_seconds'], 6)
        self.assertEqual(measured['wall_seconds'], 9)
        self.assertEqual(measured['after']['waited_children']['maximum_rss'], 1000)
        invalid = deepcopy(after); invalid['worker']['user_seconds'] = 1
        with self.assertRaises(resume.RecoveryError):
            resume.measured_usage(before, invalid, 9)

    def test_concurrency_changes_only_after_all156_old_jobs_terminal(self):
        done = dict(scheduled_seed_runs=156, canonical_terminal_seed_runs=156, running_seed_runs=0, status='complete')
        self.assertEqual(resume.workflow_concurrency_limit(done, 6), 6)
        for field, value in [('scheduled_seed_runs', 155), ('canonical_terminal_seed_runs', 155),
                             ('running_seed_runs', 1), ('status', 'running')]:
            changed = dict(done); changed[field] = value
            self.assertEqual(resume.workflow_concurrency_limit(changed, 6), 2)
        self.assertEqual(resume.workflow_concurrency_limit({}, 6), 2)
        done['atomic_accuracy_evaluated'] = False
        self.assertEqual(resume.workflow_concurrency_limit(done, 4), 4)

    def test_control_cannot_change_native_CPUs_or_exceed_root_cap(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            path = Path(directory) / 'control.json'
            path.write_text(json.dumps(dict(active_job_limit=6, stop_after_running=False)))
            self.assertEqual(resume.read_control(path, 6)['active_job_limit'], 6)
            with self.assertRaises(resume.RecoveryError):
                resume.read_control(path, 2)
            path.write_text(json.dumps(dict(active_job_limit=2, stop_after_running=False, native_cpus=2)))
            with self.assertRaises(resume.RecoveryError):
                resume.read_control(path, 6)

    def test_existing_terminal_receipt_is_pinned_and_changed_config_rejected(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            path = Path(directory); (path / 'execution.json').write_text(json.dumps(dict(
                job_id='test', terminal=True, prepared_plan=dict(sha256=resume.PLAN_SHA), config=dict(sha256='expected'))))
            job = dict(job_id='test', directory=str(path.relative_to(self.root)), config=dict(sha256='expected'))
            pins = resume._existing_receipts(self.root, dict(jobs=[job]))
            self.assertEqual(len(pins), 1)
            contents = (path / 'execution.json').read_bytes()
            resume._checked(self.root / pins[0]['path'], pins[0]['sha256'])
            self.assertEqual(contents, (path / 'execution.json').read_bytes())
            job['config']['sha256'] = 'changed'
            with self.assertRaisesRegex(resume.RecoveryError, 'config'):
                resume._existing_receipts(self.root, dict(jobs=[job]))

    def test_recovery_freeze_required_before_any_adoption_or_native_call(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            path = Path(directory) / 'freeze.json'; path.write_text('{}')
            with patch.object(resume.frozen, 'execute_job') as native:
                with self.assertRaisesRegex(resume.RecoveryError, 'recovery freeze'):
                    resume.verify_recovery_authorization(self.root, Path(directory) / 'plan.json', path)
                native.assert_not_called()

    def test_exclusive_coordinator_lock_prevents_duplicate_submission(self):
        with tempfile.TemporaryDirectory(dir=self.base) as directory:
            root = self.root.resolve(); plan = Path(directory) / 'recovery_plan.json'; plan.write_text('{}')
            lock = Path(directory) / 'coordinator.lock'; lock.write_text(json.dumps(dict(pid=999999)))
            with patch.object(resume, 'verify_recovery_authorization', return_value=(root, plan)), \
                 patch.object(resume, '_run_resume_pool_impl') as pool:
                with self.assertRaisesRegex(resume.RecoveryError, 'coordinator lock'):
                    resume.run_resume_pool(root, plan, 'unused', 'unused')
                pool.assert_not_called()
            self.assertTrue(lock.exists())


if __name__ == '__main__':
    unittest.main()
