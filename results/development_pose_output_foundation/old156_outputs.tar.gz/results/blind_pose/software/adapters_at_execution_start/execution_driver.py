"""Actual execution orchestrator; seed/box scientific settings stay in the plan.

One writer owns each box's full three-seed runs.json. The portable public CLI
can reproduce one condition; this captured driver distributes whole boxes.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import sys


def worker(task):
    root, condition, method, job, resume = task
    root = Path(root)
    sys.path.insert(0, str(root))
    from aav_benchmark.engine import dock
    from aav_benchmark.provenance import sha256
    prepared = root / 'data/processed/blind_pose' / condition / method / job['prepared_directory']
    if sha256(prepared / 'preparation.json') != job['preparation_sha256']:
        raise ValueError('Prepared box changed after condition manifest was written')
    output = root / 'results/blind_pose' / condition / method / job['id']
    rows = dock(prepared, output, root / 'tools/vina-1.2.7', root / 'benchmarks/blind_pose_experiment.json', resume=resume)
    return condition, method, job['id'], rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        parser.error('The execution policy permits at most four two-CPU workers')
    root = args.root.resolve()
    sys.path.insert(0, str(root))
    from aav_benchmark.blind_docking import planning_inventory
    from aav_benchmark.provenance import sha256, write_json
    original = root / 'results/blind_pose'
    config_path = root / 'benchmarks/blind_pose_experiment.json'
    config = json.loads(config_path.read_text())
    freeze_path = original / 'freeze_receipt.json'
    freeze = json.loads(freeze_path.read_text())
    assert freeze['configuration_sha256'] == sha256(config_path)
    assert freeze['frozen_before_new_docking'] is True
    for key, path in [('oracle_controls_sha256', original/'oracle_controls.json'),
                      ('planning_inventory_sha256', original/'planning_inventory.json'),
                      ('atomic_reference_ledger_sha256', root/'benchmarks/atomic_reference_ledger.json')]:
        assert freeze[key] == sha256(path), (key, str(path))
    before = json.loads((original/'planning_inventory.json').read_text())
    current = planning_inventory(root)
    for row in (before, current):
        row.pop('candidate_and_ligand_code_sha256', None)
    assert before == current, 'Frozen source-only candidate/chemical-input rows changed'
    vina = root/'tools/vina-1.2.7'
    lock = json.loads((root/'benchmarks/vina.lock.json').read_text())
    assert sha256(vina) in {asset['sha256'] for asset in lock['assets'].values()}
    snapshot = original/'software/adapters_at_execution_start'
    snapshot.mkdir(parents=True, exist_ok=True)
    files = [root/'aav_benchmark'/name for name in ['blind_docking.py','engine.py','aav.py','site_geometry.py','site_prediction_verification.py']]
    files.append(Path(__file__).resolve())
    for source in files:
        destination = snapshot/('execution_driver.py' if source == Path(__file__).resolve() else source.name)
        if destination.exists() and sha256(destination) != sha256(source):
            raise ValueError('Preserve first execution code snapshot; source now differs')
        if not destination.exists():
            shutil.copyfile(source, destination)
    snapshot_manifest = snapshot/'manifest.json'
    if not snapshot_manifest.exists():
        write_json(snapshot_manifest, {'created_at_UTC':datetime.now(timezone.utc).isoformat(),
            'before_first_new_docking':True,'configuration_sha256':sha256(config_path),
            'freeze_receipt_sha256':sha256(freeze_path),'python':platform.python_version(),
            'versions':{p:importlib.metadata.version(p) for p in ['numpy','scipy','gemmi','rdkit','meeko']},
            'files':{path.name:sha256(path) for path in sorted(snapshot.iterdir()) if path.is_file()},
            'note':'Code present at actual execution start; source-only candidate rows match frozen inventory. No new pose metrics consulted.'})
    lock_path = original/'execution_driver.lock'
    if lock_path.exists():
        previous = json.loads(lock_path.read_text())
        try:
            os.kill(previous['pid'],0)
        except ProcessLookupError:
            if not args.resume:
                raise ValueError('Stale driver lock exists; use explicit --resume after inspecting stopped work')
        else:
            raise ValueError('Another execution driver is already alive')
    write_json(lock_path,{'pid':os.getpid(),'configuration_sha256':sha256(config_path),'workers':args.workers})
    conditions = {}
    tasks = []
    try:
        for case in config['cases']:
            for method in config['methods']:
                name = case['condition_id']
                prepared = root/'data/processed/blind_pose'/name/method
                path = prepared/'condition.json'
                condition = json.loads(path.read_text())
                assert condition['configuration_sha256'] == sha256(config_path)
                key=(name,method)
                receipt={'schema_version':1,'condition_id':name,'complex_id':case['complex_id'],'method':method,
                         'preparation_status':condition['status'],'condition_manifest_sha256':sha256(path),
                         'configuration_sha256':sha256(config_path),'eligible_condition':True,'jobs':[],'status':'running'}
                for job in condition['jobs']:
                    row={**job,'execution_status':'queued' if job['status']=='prepared' else 'preparation_failed','runs':[]}
                    receipt['jobs'].append(row)
                    if job['status']=='prepared':
                        tasks.append((str(root),name,method,job,args.resume))
                if not receipt['jobs']:
                    receipt['status']='workflow_failed'
                conditions[key]=receipt
                write_json(original/name/method/'condition_runs.json',receipt)
        assert len(conditions)==27 and len(tasks)==52
        # A long 2VUZ box begins immediately while the other workers process
        # shorter boxes. Remaining 2VUZ boxes then share all idle workers.
        tasks.sort(key=lambda t:(t[1]=='2VUZ', not t[1].startswith('aav9'),t[1],t[2],t[3]['id']))
        heavy=next(t for t in tasks if t[1]=='2VUZ')
        tasks.remove(heavy)
        tasks.insert(0,heavy)
        print('SCIENTIFIC EXECUTION START',datetime.now(timezone.utc).isoformat(),'boxes',len(tasks),'scheduled seeds',len(tasks)*len(config['seeds']),'workers',args.workers,flush=True)
        def checkpoint():
            seed_rows=[]
            for _,name,method,job,_ in tasks:
                path=original/name/method/job['id']/'runs.json'
                if path.exists():
                    seed_rows.extend(json.loads(path.read_text()))
            write_json(original/'execution_progress.json',{'configuration_sha256':sha256(config_path),
                'driver_pid':os.getpid(),'workers':args.workers,'scheduled_box_count':52,'scheduled_seed_runs':156,
                'observed_seed_records':len(seed_rows),'successful_seed_runs':sum(r['status']=='ok' for r in seed_rows),
                'failed_seed_runs':sum(r['status']=='failed' for r in seed_rows),'running_seed_runs':sum(r['status']=='running' for r in seed_rows),
                'complete_boxes':sum(j['execution_status'] in ['ok','execution_failed'] for r in conditions.values() for j in r['jobs']),
                'status':'running','updated_at_UTC':datetime.now(timezone.utc).isoformat()})
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures={pool.submit(worker,t):t for t in tasks}
            while futures:
                done,_=wait(futures,timeout=30,return_when=FIRST_COMPLETED)
                for future in done:
                    task=futures.pop(future)
                    name,method,box_id,rows=future.result()
                    receipt=conditions[(name,method)]
                    row=next(j for j in receipt['jobs'] if j['id']==box_id)
                    row['runs']=rows
                    row['execution_status']='ok' if all(r['status']=='ok' for r in rows) else 'execution_failed'
                    if all(j['execution_status']!='queued' for j in receipt['jobs']):
                        receipt['status']='ok' if all(j['execution_status']=='ok' for j in receipt['jobs']) else 'workflow_failed'
                    write_json(original/name/method/'condition_runs.json',receipt)
                    print('BOX FINISHED',name,method,box_id,row['execution_status'],flush=True)
                checkpoint()
        progress=json.loads((original/'execution_progress.json').read_text())
        progress['status']='complete'
        write_json(original/'execution_progress.json',progress)
        print('ALL SCHEDULED BOXES COMPLETE',datetime.now(timezone.utc).isoformat(),flush=True)
    finally:
        lock_path.unlink(missing_ok=True)


if __name__=='__main__':
    main()
